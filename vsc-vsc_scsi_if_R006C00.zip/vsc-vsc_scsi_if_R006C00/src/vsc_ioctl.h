/********************************************************************
            Copyright (C) Huawei Technologies, 2012
  #����:  

********************************************************************/
#include "vsc_common.h"

#ifndef __VSC_IOCTL_H_
#define __VSC_IOCTL_H_


int __init vsc_ioctl_init(void);

void vsc_ioctl_exit(void);

#endif
